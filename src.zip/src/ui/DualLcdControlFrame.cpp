#include "DualLcdControlFrame.h"
#include "DysektLookAndFeel.h"
#include "../PluginProcessor.h"
#include "../params/ParamIds.h"

DualLcdControlFrame::DualLcdControlFrame (DysektProcessor& p)
    : processor (p)
{
    // No child components — all drawing is manual.
}

// ── drawIcon ──────────────────────────────────────────────────────────────────

void DualLcdControlFrame::drawIcon (juce::Graphics& g, juce::Rectangle<float> b,
                                    int type, bool active)
{
    const auto accent = getTheme().accent;
    const auto fg     = getTheme().foreground;

    if (active)
    {
        g.setColour (accent.withAlpha (0.22f));
        g.fillRoundedRectangle (b.reduced (2.0f), 4.0f);
        g.setColour (accent.withAlpha (0.70f));
        g.drawRoundedRectangle (b.reduced (1.5f), 4.0f, 1.2f);
    }

    float cx  = b.getCentreX();
    float cy2 = b.getCentreY();
    auto  col = active ? accent : fg.withAlpha (0.75f);
    g.setColour (col);

    if (type == 0) // Folder / Browser
    {
        g.fillRoundedRectangle (cx - 8, cy2 - 3, 7, 3, 1.0f);
        g.fillRoundedRectangle (cx - 9, cy2 - 2, 18, 11, 1.5f);
    }
    else if (type == 1) // Waveform
    {
        float pts[] = { -8,-1, -6,-4, -4,0, -2,4, 0,-6, 2,6, 4,-2, 6,2, 8,0 };
        juce::Path p;
        for (int i = 0; i < 9; i++)
        {
            float px = cx + pts[i*2], py = cy2 + pts[i*2+1];
            i == 0 ? p.startNewSubPath (px, py) : p.lineTo (px, py);
        }
        g.strokePath (p, juce::PathStrokeType (1.5f));
    }
    else if (type == 2) // MIDI Follow — 5-pin DIN connector
    {
        // Outer D-shell body (semicircle top, flat bottom)
        const float bW = 16.0f, bH = 10.0f;
        const float bX = cx - bW * 0.5f, bY = cy2 - 4.0f;

        // Body fill + stroke
        juce::Path body;
        body.addRoundedRectangle (bX, bY, bW, bH, 2.5f);
        g.setColour (col.withAlpha (active ? 0.18f : 0.09f));
        g.fillPath (body);
        g.setColour (col.withAlpha (active ? 0.90f : 0.55f));
        g.strokePath (body, juce::PathStrokeType (1.2f));

        // 5 pins arranged in a D-sub arc inside the body
        // Standard MIDI DIN layout: 3 on top row, 2 on bottom row
        struct Pin { float x, y; };
        const float pr = 1.5f;  // pin radius
        const float pc = active ? 0.95f : 0.60f;

        Pin pins[5] = {
            { cx - 5.0f, bY + 3.0f },   // pin 1 (top-left)
            { cx,        bY + 2.2f },   // pin 2 (top-centre)
            { cx + 5.0f, bY + 3.0f },   // pin 3 (top-right)
            { cx - 2.8f, bY + 6.5f },   // pin 4 (bottom-left)
            { cx + 2.8f, bY + 6.5f },   // pin 5 (bottom-right)
        };

        for (const auto& p : pins)
        {
            // Pin hole outline
            g.setColour (col.withAlpha (pc));
            g.drawEllipse (p.x - pr, p.y - pr, pr * 2.0f, pr * 2.0f, 1.0f);
            // Pin centre dot
            g.setColour (col.withAlpha (active ? 0.70f : 0.30f));
            g.fillEllipse (p.x - 0.7f, p.y - 0.7f, 1.4f, 1.4f);
        }

        // Small cable stub at bottom
        g.setColour (col.withAlpha (active ? 0.75f : 0.40f));
        g.drawLine (cx, bY + bH, cx, bY + bH + 3.5f, 1.5f);
        g.fillEllipse (cx - 2.0f, bY + bH + 3.0f, 4.0f, 3.0f);
    }
    else if (type == 4) // SFZ / SF2 instrument — mini piano keys
    {
        const float keyW  = 5.0f;
        const float keyH  = 11.0f;
        const float startX = cx - keyW * 1.5f - 3.0f;
        const float keyY  = cy2 - keyH * 0.5f;

        // Three white keys
        for (int k = 0; k < 3; ++k)
        {
            float kx = startX + k * (keyW + 1.0f);
            g.setColour (active ? accent.withAlpha (0.20f) : fg.withAlpha (0.08f));
            g.fillRoundedRectangle (kx, keyY, keyW, keyH, 1.0f);
            g.setColour (col);
            g.drawRoundedRectangle (kx, keyY, keyW, keyH, 1.0f, 1.0f);
        }

        // Two black keys between white keys
        const float bkW = 3.5f, bkH = 6.5f;
        g.setColour (col.withAlpha (active ? 0.95f : 0.70f));
        g.fillRoundedRectangle (startX + keyW - bkW * 0.5f,                 keyY, bkW, bkH, 0.8f);
        g.fillRoundedRectangle (startX + keyW * 2.0f + 1.0f - bkW * 0.5f,  keyY, bkW, bkH, 0.8f);
    }
    else // type == 3: Mixer — three vertical faders at different positions
    {
        // Three fader grooves
        const float grooveH = 12.0f;
        const float grooveW = 2.0f;
        float gx[] = { cx - 7.0f, cx, cx + 7.0f };

        for (float x : gx)
        {
            g.fillRoundedRectangle (x - grooveW / 2, cy2 - grooveH / 2,
                                    grooveW, grooveH, 1.0f);
        }

        // Three thumbs at different heights (classic mixer look)
        float thumbY[] = { cy2 - 3.0f, cy2 + 1.0f, cy2 - 6.0f };
        const float thumbW = 7.0f, thumbH = 4.0f;

        g.setColour (active ? accent.brighter (0.3f) : fg.withAlpha (0.90f));
        for (int i = 0; i < 3; ++i)
            g.fillRoundedRectangle (gx[i] - thumbW / 2, thumbY[i], thumbW, thumbH, 1.5f);
    }
}

// ── paint ─────────────────────────────────────────────────────────────────────

void DualLcdControlFrame::paint (juce::Graphics& g)
{
    const auto accent = getTheme().accent;
    const auto fg     = getTheme().foreground;
    const int  w      = getWidth();
    const int  h      = getHeight();
    const int  half   = h / 2;

    // ── Background + border ───────────────────────────────────────────────────
    {
        auto bgTop = getTheme().darkBar.darker (0.45f);
        auto bgBot = getTheme().darkBar.darker (0.65f);
        juce::ColourGradient grad (bgTop, 0, 0, bgBot, 0, (float) h, false);
        g.setGradientFill (grad);
        g.fillRoundedRectangle (getLocalBounds().toFloat(), 4.0f);
        g.setColour (accent.withAlpha (0.18f));
        g.drawRoundedRectangle (getLocalBounds().toFloat().expanded (1.0f), 5.0f, 1.0f);
        g.setColour (accent.withAlpha (0.60f));
        g.drawRoundedRectangle (getLocalBounds().toFloat().reduced (0.5f), 4.0f, 1.5f);
    }

    // ── Divider ───────────────────────────────────────────────────────────────
    g.setColour (accent.withAlpha (0.25f));
    g.drawHorizontalLine (half, 6.0f, (float) w - 6.0f);

    // ── EDIT | PAD mode tab strip (centred on divider) ────────────────────────
    {
        const int tabH    = 15;
        const int tabW    = 42;
        const int tabGap  = 4;
        const int totalTW = tabW * 2 + tabGap;
        const int tabX    = (w - totalTW) / 2;
        const int tabY    = half - tabH / 2;

        editTabArea = { tabX,                tabY, tabW, tabH };
        padTabArea  = { tabX + tabW + tabGap, tabY, tabW, tabH };

        // Erase the divider line behind the tabs so they float cleanly
        {
            auto bgTop = getTheme().darkBar.darker (0.45f);
            auto bgBot = getTheme().darkBar.darker (0.65f);
            // Sample approx mid-gradient colour at divider
            auto bgMid = bgTop.interpolatedWith (bgBot, 0.5f);
            g.setColour (bgMid);
            g.fillRect (tabX - 2, tabY, totalTW + 4, tabH);
        }

        auto drawTab = [&] (juce::Rectangle<int> r, const char* label, bool active)
        {
            juce::Rectangle<float> rf = r.toFloat();
            if (active)
            {
                g.setColour (accent.withAlpha (0.28f));
                g.fillRoundedRectangle (rf, 3.0f);
                g.setColour (accent.withAlpha (0.85f));
                g.drawRoundedRectangle (rf.reduced (0.5f), 3.0f, 1.1f);
                g.setColour (accent);
            }
            else
            {
                g.setColour (fg.withAlpha (0.10f));
                g.fillRoundedRectangle (rf, 3.0f);
                g.setColour (fg.withAlpha (0.28f));
                g.drawRoundedRectangle (rf.reduced (0.5f), 3.0f, 0.7f);
                g.setColour (fg.withAlpha (0.50f));
            }
            g.setFont (DysektLookAndFeel::makeFont (7.5f, true));
            g.drawText (label, r, juce::Justification::centred);
        };

        drawTab (editTabArea, "EDIT", ! padGridActive);
        drawTab (padTabArea,  "SFZ",  padGridActive);
    }

    // ── Top row: four icons evenly spread across full width ──────────────────
    {
        const int btnSz  = 32;
        const int btnY   = (half - btnSz) / 2;
        const int gap    = (w - 4 * btnSz) / 5;

        filIconArea        = { gap,                       btnY, btnSz, btnSz };
        waIconArea         = { gap * 2 + btnSz,           btnY, btnSz, btnSz };
        midiFollowIconArea = { gap * 3 + btnSz * 2,       btnY, btnSz, btnSz };
        bodeIconArea       = { gap * 4 + btnSz * 3,       btnY, btnSz, btnSz };
        sfzIconArea        = {};

        drawIcon (g, filIconArea       .toFloat(), 0, browserActive);
        drawIcon (g, waIconArea        .toFloat(), 1, waveMode != 0);
        drawIcon (g, midiFollowIconArea.toFloat(), 2, midiFollowActive);
        drawIcon (g, bodeIconArea      .toFloat(), 3, bodeActive);

        // ── Hover tooltip label ──────────────────────────────────────
        if (hoveredIcon >= 0)
        {
            static const char* kLabels[] = { "FILE BROWSER", "WAVEFORM", "MIDI FOLLOW", "MIXER" };
            const juce::Rectangle<int>* areas[] = { &filIconArea, &waIconArea,
                                                     &midiFollowIconArea, &bodeIconArea };
            const auto& area = *areas[hoveredIcon];
            const int labelH  = 9;
            const int labelY  = area.getY() - labelH - 2;
            g.setFont (DysektLookAndFeel::makeFont (7.0f));
            g.setColour (getTheme().accent.withAlpha (0.80f));
            g.drawText (kLabels[hoveredIcon], area.getX() - 20, labelY, area.getWidth() + 40, labelH,
                        juce::Justification::centred);
        }
    }

    // ── Bottom row: ROOT | PITCH | VOL knobs ─────────────────────────────────
    {
        const auto& ui = processor.getUiSliceSnapshot();
        float gPitch = processor.apvts.getRawParameterValue (ParamIds::defaultPitch)->load();
        float gVol   = processor.apvts.getRawParameterValue (ParamIds::masterVolume)->load();
        float rootN  = (float) ui.rootNote / 127.0f;
        float pitchN = (gPitch + 48.0f) / 96.0f;
        float volN   = (gVol + 100.0f) / 124.0f;

        static const char* noteNames[] = { "C","C#","D","D#","E","F","F#","G","G#","A","A#","B" };
        int rn = juce::jlimit (0, 127, ui.rootNote);
        juce::String rootStr  = juce::String (noteNames[rn % 12]) + juce::String (rn / 12 - 2);
        juce::String pitchStr = (gPitch >= 0.0f ? "+" : "") + juce::String ((int) std::round (gPitch));
        juce::String volStr   = (gVol >= 0.0f ? "+" : "") + juce::String (gVol, 1);

        const int kr  = 12;
        const float kStart = juce::MathConstants<float>::pi * 1.25f;
        const float kEnd   = juce::MathConstants<float>::pi * 2.75f;

        int kcy  = half + (h - half) / 2 - 5;
        int k1cx = w / 6;
        int k2cx = w / 2;
        int k3cx = w * 5 / 6;

        struct Knob { int cx; float norm; juce::String lbl; juce::String val; };
        Knob knobs[] = {
            { k1cx, rootN,  "ROOT",  rootStr  },
            { k2cx, pitchN, "PITCH", pitchStr },
            { k3cx, volN,   "VOL",   volStr   },
        };

        for (auto& k : knobs)
        {
            float angle = kStart + k.norm * (kEnd - kStart);

            juce::Path track;
            track.addCentredArc ((float)k.cx,(float)kcy,(float)kr,(float)kr,0.f,kStart,kEnd,true);
            g.setColour (getTheme().darkBar.brighter (0.3f));
            g.strokePath (track, juce::PathStrokeType (1.5f));

            juce::Path arc;
            arc.addCentredArc ((float)k.cx,(float)kcy,(float)kr,(float)kr,0.f,kStart,angle,true);
            g.setColour (accent);
            g.strokePath (arc, juce::PathStrokeType (2.2f));

            float lr = (float) kr - 2.0f;
            g.setColour (accent.brighter (0.3f));
            g.drawLine ((float)k.cx, (float)kcy,
                        (float)k.cx + lr * std::cos (angle),
                        (float)kcy  + lr * std::sin (angle), 1.3f);

            g.setFont (DysektLookAndFeel::makeFont (7.5f, true));
            g.setColour (fg.withAlpha (0.45f));
            g.drawText (k.lbl, k.cx - 16, kcy + kr + 2, 32, 9, juce::Justification::centred);

            g.setFont (DysektLookAndFeel::makeFont (8.0f));
            g.setColour (accent.withAlpha (0.80f));
            g.drawText (k.val, k.cx - 18, kcy + kr + 11, 36, 9, juce::Justification::centred);
        }

        rootKnobArea  = { k1cx - kr - 5, kcy - kr - 3, (kr + 5) * 2, (kr + 5) * 2 };
        pitchKnobArea = { k2cx - kr - 5, kcy - kr - 3, (kr + 5) * 2, (kr + 5) * 2 };
        volKnobArea   = { k3cx - kr - 5, kcy - kr - 3, (kr + 5) * 2, (kr + 5) * 2 };
    }
}

// ── Mouse ─────────────────────────────────────────────────────────────────────

void DualLcdControlFrame::mouseDown (const juce::MouseEvent& e)
{
    if (textEditor) textEditor.reset();

    auto pos = e.getPosition();
    dragTarget = DragTarget::None;

    // Icon toggles
    if (filIconArea.contains (pos))
    {
        browserActive = ! browserActive;
        repaint();
        if (onBrowserToggle) onBrowserToggle();
        return;
    }
    if (waIconArea.contains (pos))
    {
        setWaveMode ((waveMode + 1) % 8);
        repaint();
        if (onWaveToggle) onWaveToggle();
        return;
    }
    if (midiFollowIconArea.contains (pos))
    {
        midiFollowActive = ! midiFollowActive;
        repaint();
        if (onMidiFollowToggle) onMidiFollowToggle();
        return;
    }
    if (bodeIconArea.contains (pos))
    {
        bodeActive = ! bodeActive;
        repaint();
        if (onBodeToggle) onBodeToggle();
        return;
    }

    // ── EDIT | SFZ tabs ──────────────────────────────────────────────────────
    if (editTabArea.contains (pos))
    {
        if (padGridActive)
        {
            padGridActive = false;
            repaint();
            if (onUiModeChanged) onUiModeChanged (0);
        }
        return;
    }
    if (padTabArea.contains (pos))
    {
        if (! padGridActive)
        {
            padGridActive = true;
            repaint();
            if (onUiModeChanged) onUiModeChanged (1);
        }
        return;
    }

    // Knobs
    if (rootKnobArea.contains (pos))
    {
        dragTarget     = DragTarget::Root;
        dragStartY     = pos.y;
        dragStartValue = (float) processor.getUiSliceSnapshot().rootNote;
        return;
    }
    if (pitchKnobArea.contains (pos))
    {
        dragTarget     = DragTarget::Pitch;
        dragStartY     = pos.y;
        dragStartValue = processor.apvts.getRawParameterValue (ParamIds::defaultPitch)->load();
        if (auto* p = processor.apvts.getParameter (ParamIds::defaultPitch))
            p->beginChangeGesture();
        return;
    }
    if (volKnobArea.contains (pos))
    {
        dragTarget     = DragTarget::Volume;
        dragStartY     = pos.y;
        dragStartValue = processor.apvts.getRawParameterValue (ParamIds::masterVolume)->load();
        if (auto* p = processor.apvts.getParameter (ParamIds::masterVolume))
            p->beginChangeGesture();
        return;
    }
}

void DualLcdControlFrame::mouseDrag (const juce::MouseEvent& e)
{
    const float delta = (float) (dragStartY - e.y);

    switch (dragTarget)
    {
        case DragTarget::Root:
        {
            float sens  = e.mods.isShiftDown() ? 0.1f : 0.4f;
            int newRoot = juce::jlimit (0, 127, (int) std::round (dragStartValue + delta * sens));
            DysektProcessor::Command cmd;
            cmd.type      = DysektProcessor::CmdSetRootNote;
            cmd.intParam1 = newRoot;
            processor.pushCommand (cmd);
            repaint();
            break;
        }
        case DragTarget::Pitch:
        {
            float sens = e.mods.isShiftDown() ? 0.05f : 0.5f;
            float newV = juce::jlimit (-48.0f, 48.0f, dragStartValue + delta * sens);
            if (auto* p = processor.apvts.getParameter (ParamIds::defaultPitch))
                p->setValueNotifyingHost (p->convertTo0to1 (newV));
            repaint();
            break;
        }
        case DragTarget::Volume:
        {
            float sens = e.mods.isShiftDown() ? 0.1f : 1.0f;
            float newV = juce::jlimit (-100.0f, 24.0f, dragStartValue + delta * sens);
            if (auto* p = processor.apvts.getParameter (ParamIds::masterVolume))
                p->setValueNotifyingHost (p->convertTo0to1 (newV));
            repaint();
            break;
        }
        default: break;
    }
}

void DualLcdControlFrame::mouseUp (const juce::MouseEvent&)
{
    if (dragTarget == DragTarget::Pitch)
        if (auto* p = processor.apvts.getParameter (ParamIds::defaultPitch))
            p->endChangeGesture();
    if (dragTarget == DragTarget::Volume)
        if (auto* p = processor.apvts.getParameter (ParamIds::masterVolume))
            p->endChangeGesture();
    dragTarget = DragTarget::None;
}

void DualLcdControlFrame::mouseDoubleClick (const juce::MouseEvent& e)
{
    if (! rootKnobArea.contains (e.getPosition())) return;

    const auto& ui = processor.getUiSliceSnapshot();
    textEditor = std::make_unique<juce::TextEditor>();
    addAndMakeVisible (*textEditor);
    textEditor->setBounds (rootKnobArea.getX(), rootKnobArea.getBottom() - 16,
                           rootKnobArea.getWidth(), 16);
    textEditor->setFont (DysektLookAndFeel::makeFont (12.0f));
    textEditor->setColour (juce::TextEditor::backgroundColourId,
                           getTheme().header.brighter (0.2f));
    textEditor->setColour (juce::TextEditor::textColourId,    juce::Colours::white);
    textEditor->setColour (juce::TextEditor::outlineColourId, getTheme().accent);
    textEditor->setText (juce::String (ui.rootNote), false);
    textEditor->selectAll();
    textEditor->grabKeyboardFocus();

    textEditor->onReturnKey = [this] {
        if (! textEditor) return;
        int val = juce::jlimit (0, 127, textEditor->getText().getIntValue());
        DysektProcessor::Command cmd;
        cmd.type      = DysektProcessor::CmdSetRootNote;
        cmd.intParam1 = val;
        processor.pushCommand (cmd);
        textEditor.reset();
        repaint();
    };
    textEditor->onEscapeKey = [this] { textEditor.reset(); repaint(); };
    textEditor->onFocusLost = [this] { textEditor.reset(); repaint(); };
}

void DualLcdControlFrame::mouseMove (const juce::MouseEvent& e)
{
    const auto pos = e.getPosition();
    int found = -1;
    if (filIconArea.contains (pos))             found = 0;
    else if (waIconArea.contains (pos))         found = 1;
    else if (midiFollowIconArea.contains (pos)) found = 2;
    else if (bodeIconArea.contains (pos))       found = 3;

    if (found != hoveredIcon)
    {
        hoveredIcon = found;
        repaint();
    }
}

void DualLcdControlFrame::mouseExit (const juce::MouseEvent&)
{
    if (hoveredIcon != -1)
    {
        hoveredIcon = -1;
        repaint();
    }
}
